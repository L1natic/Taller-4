import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        /**creacion de un nuevo objeto de la clase factura*/
        Factura cliente =new Factura();
                Scanner sc2 =new Scanner(System.in);
                String respuesta;
                /**bucle do -while para repeticion*/
                do {
                    /**llamado de los metodos creados*/
                    cliente.ingreso();
                    cliente.impreso();
                    System.out.println("Quiere ingresar otra factura");
                    respuesta= sc2.nextLine();
                }while(respuesta.equalsIgnoreCase("si"));


    }
}