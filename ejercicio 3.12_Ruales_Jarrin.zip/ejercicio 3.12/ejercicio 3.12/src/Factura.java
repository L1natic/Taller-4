import java.util.Scanner;

public class Factura {
    /**creacion de los atributos de la clase */
    private String npieza;
    private String pieza;
    private int cantidad;
    private double precio;
   /**metodos propios de java*/
     Scanner sc=new Scanner(System.in);


    public String getNpieza() {
        return npieza;
    }

    public void setNpieza(String npieza) {
        this.npieza = npieza;
    }

    public String getPieza() {
        return pieza;
    }

    public void setPieza(String pieza) {
        this.pieza = pieza;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    /**metodos creados */

    public Factura() {
    }
    public void ingreso(){



            System.out.println("ingrese la pieza que va a comprar:");
            this.setPieza(sc.nextLine());
            System.out.println("ingrese el numero de seria de la pieza que va a comprar");
            this.setNpieza(sc.nextLine());
            System.out.println("ingrese la cantidad que va a comprar");
            this.setCantidad(Integer.parseInt(sc.nextLine()));
            if (cantidad<0){
                this.cantidad=0;
            }
            System.out.println("ingrese el precio unitario del producto");
            this.setPrecio(Double.parseDouble(sc.nextLine()));
            if (precio<0){
                this.precio=0.0;
            }


    }

    public  double obtenerMontoFactura(){
            double total;
            total=getCantidad()*getPrecio();
            return total;
    }

    public void impreso(){
        System.out.println("Factura creada");
        System.out.println("la pieza comprada es: "+getPieza());
        System.out.println("su numero de series es :"+getNpieza());
        System.out.println("la cantidad comprada es:"+getCantidad());
        System.out.println("con el precio de :"+getPrecio());
        System.out.println("el total de la factura es "+obtenerMontoFactura());
    }


}
