
//Crea una clase llamada Empleado, que incluya tres variables de instancia:
//un nombre (tipo String), un apellido(tipo String), y un salario (tipo double)
//Su clase debe tener un constructor que inicialice las tres variables de instancia
//Proporcione un metodo establecer y un metodo obtener para cada variable de instancia
//Si el salario mensual no es positivo, no establezca su valor
//Escriba una aplicación de prueba llamada PruebaEmpleado
//Cree dos objetos Empleado y muestre el salario anual de cada objeto
//Despues, proporcione a cada Empleado un aumento del 10% y muestre el salario anual de cada Empleado
void main() {
    /**Creación de Objetos*/
    Empleado empleado1= new Empleado("Pedro","Paramo",1230);
    Empleado empleado2= new Empleado();
    /**Ingreso de datos*/
    //empleado1.ingreso_datos();
    empleado2.ingreso_datos();
    /**Impresión de datos iniciales*/
    empleado1.imprimir_datos_iniciales();
    empleado1.idi();
    System.out.println("-----------------------------------------");
    empleado2.imprimir_datos_iniciales();
    empleado2.idi();
    /**Cálculo e impresión de datos finales*/
    System.out.println("------------------Aumento de salario de 10%------------------");
    empleado1.imprimir_datos_finales();
    empleado1.idf();
    System.out.println("-----------------------------------------");
    empleado2.imprimir_datos_finales();
    empleado2.idf();
}
