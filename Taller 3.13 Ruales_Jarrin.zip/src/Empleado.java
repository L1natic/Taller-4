import javax.swing.*;

import static javax.swing.JOptionPane.*;

public class Empleado {
    String nombre;
    String apellido;
    double salario;
    /**Definición de clases*/
    public Empleado(String nombre, String apellido, double salario){
        this.nombre=nombre;
        this.apellido=apellido;
        this.salario=salario;
    }
    public Empleado(){

    }
    /**Ingresa los datos del usuario*/
    public void ingreso_datos(){
        this.nombre= JOptionPane.showInputDialog("Ingrese su nombre: ");
        this.apellido= showInputDialog("Ingrese su apellido: ");
        this.salario=Integer.parseInt(showInputDialog("Ingrese su salario mensual: "));
        if(this.salario<0){
            this.salario=0;
        }
    }
    /**Imprime los valores iniciales del usuario*/
    public void imprimir_datos_iniciales(){
        System.out.println("Nombre: " + this.nombre +" " + this.apellido);
        System.out.println("Salario mensual: $" + this.salario);
        System.out.println("Salario anual: $" + (this.salario*12));
    }
    public void idi(){
        showMessageDialog(null,"Nombre: "+this.nombre+" " + this.apellido +"\n "
                + " Salario mensual: $" + this.salario + "\n"
                + "Salario anual: $" + (this.salario*12)
        );
    }
    /**Calcula el aumento del 10% e imprime los valores finales en consola*/
    public void imprimir_datos_finales(){
        this.salario=this.salario+(this.salario*0.10);
        System.out.println("Nombre: " + this.nombre +" " + this.apellido);
        System.out.println("Salario mensual con aumento: $" + this.salario);
        System.out.println("Salario anual con aumento: $" + (this.salario*12));
    }
    /**Calcula el aumento del 10% e imprime los valores finales en caja*/
    public void idf(){
        this.salario=this.salario+(this.salario*0.10);
        showMessageDialog(null,"Nombre: "+this.nombre+" " + this.apellido +"\n "
                        + " Salario mensual con aumento: $" + this.salario + "\n"
                        + "Salario anual con aumento: $" + (this.salario*12)
                );
    }
}
