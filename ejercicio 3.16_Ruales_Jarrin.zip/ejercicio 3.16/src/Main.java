import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
           /**creacion de objetos e inicializacion de variables*/
             FrecuenciaCardiaca cliente =new FrecuenciaCardiaca();
            FrecuenciaCardiaca cliente2= new FrecuenciaCardiaca();
            int anioactual=2025;
            int edad;
            int frecuancia;
            double fa;
            double frecuenciae = 0;
            int dias = 0;
            Scanner sc2 =new Scanner(System.in);
        /** lectura de variable nombre,apellido,año,mes,dia y genero*/

        cliente.ingreso();
       /**calculo de edad mediante metodo calcular edad*/
       edad= cliente.calcularEdad();
       /** calculo de dia mediante metodo calcular dia*/
        dias= cliente.calcularDias();

       /**calculo de frecuencia restando 220 menos la edad*/
        frecuancia=220-edad;

      /**calculo de frecuencia maxima y frecuencia esperada*/
        do {
            System.out.println("ingrese el rango en el cual cree que se encuentra su frecuencia cardiaca 50-85%");
            cliente.setRangof(Integer.parseInt(sc2.nextLine()));
            /**Validacion de rango de frecuencia cardiaca*/
            if (cliente.getRangof() < 50 || cliente.getRangof() > 85){
                System.out.println("No se encuentra en el rango de pulsaciones (50-85)");

            }
        }while (cliente.getRangof()<50 ||cliente.getRangof()>85);




            fa = cliente.getRangof() / 100.0;


            frecuenciae = frecuancia * fa;


            if (cliente.getGenero().equalsIgnoreCase("hombre")) {
                frecuenciae += 0.5; // Aumenta 0.5 a la frecuencia FINAL
                System.out.println("Ajuste por género aplicado (+0.5% latidos).");
            }

         /**impresion de valores*/
        System.out.println("el usuario con el nombre "+" "+ cliente.getNombre()+ "  y el apellido" +" "+cliente.getApellido());
        System.out.println("su edad es :" +"  "+edad+ " con un total de"+ " " +dias+ " dias");
        System.out.println("su frecuencia cardiaca maxima es:"+frecuancia);
        System.out.println("La frecuencia cardiaca esperada es de  :"+frecuenciae);


    }
}