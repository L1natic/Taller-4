import javax.swing.*;
import java.util.Scanner;

public class Fecha {
    int day;
    int month;
    int year;

    Scanner sc = new Scanner(System.in);

    public Fecha(int day, int month, int year){
        this.day=day;
        this.month=month;
        this.year=year;
    }
    public Fecha(){

    }

    public void setDay(int day) {
        this.day = day;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void dia_validacion(){
        this.day=0;
        if(this.month%2==1){
            while(this.day>30 || this.day<1){
                this.day=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dia actual: "));
                if(this.day>30 || this.day<1){
                    JOptionPane.showMessageDialog(null, "Valor no permitido, ingrese un valor entre 30 y 1");
                }
            }
        }else if (this.month!=2){
            while(this.day>31 || this.day<1){
                this.day=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dia actual: "));
                if(this.day>31 || this.day<1){
                    JOptionPane.showMessageDialog(null, "Valor no permitido, ingrese un valor entre 31 y 1");
                }
            }
        }else{
            while(this.day>28 || this.day<1){
                this.day=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dia actual: "));
                if(this.day>28 || this.day<1){
                    JOptionPane.showMessageDialog(null, "Valor no permitido, ingrese un valor entre 28 y 1");
                }
            }
        }
    }
    public void mes_validacion(){
        this.month=0;
        while(this.month>12 || this.month<1){
            this.month=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el mes actual: "));
            if(this.month>12 || this.month<1){
                JOptionPane.showMessageDialog(null, "Valor no permitido, ingrese un valor entre 12 y 1");
            }
        }
    }
    public void year_validacion(){
        this.year=0;
        while(this.year>2026 || this.year<1969){
            this.year=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el año actual: "));
            if(this.year>2026 || this.year<1969){
                JOptionPane.showMessageDialog(null, "Valor no permitido, ingrese un valor entre 1969 y 2026");
            }
        }
    }
}
