/*Los atributos de la clase deben incluir el primer nombre de
la persona, su apellido, sexo, fecha de nacimiento (que debe consistir de
atributos separados para el día, mes y año de nacimiento),
altura (en centímetros) y peso (en kilogramos).
Su clase debe tener un constructor que reciba estos datos. */

import java.util.Scanner;

public class PerfilMedico {
    /**Creacion de atributos*/
    private String nombre;
    private String apellido;
    private String sexo;
    private Integer year_nacimiento;
    private Integer mes_nacimiento;
    private Integer dia_nacimiento;
    private Double altura_cm;
    private Double peso_kg;


    /**Creacion de Constructor*/

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    public void setYear_nacimiento(Integer year_nacimiento) {
        this.year_nacimiento = year_nacimiento;
    }
    public void setMes_nacimiento(Integer mes_nacimiento) {
        this.mes_nacimiento = mes_nacimiento;
    }
    public void setDia_nacimiento(Integer dia_nacimiento) {
        this.dia_nacimiento = dia_nacimiento;
    }
    public void setAltura_cm(Double altura_cm) {
        this.altura_cm = altura_cm;
    }
    public void setPeso_kg(Double peso_kg) {
        this.peso_kg = peso_kg;
    }

    /**
     * Metodos Propios
     * return
     */
    public void Despliegue() {
        /* DATOS GENERALES */
        Fecha fecha_actual = new Fecha();
        Scanner sc = new Scanner(System.in);
        // Año actual
        fecha_actual.year_validacion();

        // Mes actual
        System.out.print("Ingrese el mes: ");

        fecha_actual.mes_validacion();
        System.out.println();
        // Día actual

        System.out.print("Ingrese el día: ");
        System.out.println();
        fecha_actual.dia_validacion();
        int d1 = fecha_actual.day;

        while (d1 == 1) {
            System.out.print("Ingrese el día de nuevo: ");
            fecha_actual.dia_validacion();
            d1 = fecha_actual.day;
        }

        System.out.println("Hoy es: " + fecha_actual.day + "/" + fecha_actual.month + "/" + fecha_actual.year);

        /* DATOS DEL PACIENTE */

        //sc.nextLine(); // Limpieza del buffer
        System.out.print("Ingrese el apellido del paciente: ");
        this.setApellido(sc.nextLine());

        System.out.print("Ingrese el nombre del paciente: ");
        this.setNombre(sc.nextLine());

        System.out.print("Ingrese el sexo del paciente (M/F): ");
        this.setSexo(sc.nextLine());

        System.out.println("FECHA DE NACIMIENTO:");
        int yearNacimiento;
        do {
            System.out.print("  Ingrese el año: ");
            yearNacimiento = sc.nextInt();

            if (yearNacimiento > 2025) {
                System.out.println("Año inválido. Debe ser menor o igual a 2025.");
            } else if (yearNacimiento < 1900) {
                System.out.println("Año inválido. Ingrese un año razonable (>=1900).");
            }
        } while (yearNacimiento > 2025 || yearNacimiento < 1900);
        this.setYear_nacimiento(yearNacimiento);

        int mesNacimiento;
        do {
            System.out.print("  Ingrese el mes: ");
            mesNacimiento = sc.nextInt();

            if (mesNacimiento < 1 || mesNacimiento > 12) {
                System.out.println("Mes inválido. Debe estar entre 1 y 12.");
            }
        } while (mesNacimiento < 1 || mesNacimiento > 12);
        this.setMes_nacimiento(mesNacimiento);

        int diaNacimiento;
        do {
            System.out.print("  Ingrese el día: ");
            diaNacimiento = sc.nextInt();

            if (diaNacimiento < 1 || diaNacimiento > 31) {
                System.out.println("Día inválido. Debe estar entre 1 y 31.");
            }
        } while (diaNacimiento < 1 || diaNacimiento > 31);
        this.setDia_nacimiento(diaNacimiento);

        double altura;
        do {
            System.out.print("Ingrese la altura (cm): ");
            altura = sc.nextDouble();

            if (altura <= 0) {
                System.out.println("Altura inválida. Debe ser un valor positivo mayor que 0 cm.");
            } else if (altura > 300) {
                System.out.println("Altura inusual. Ingrese un valor realista (menor a 300 cm).");
            }
        } while (altura <= 0 || altura > 300);
        this.setAltura_cm(altura);

        double peso;
        do {
            System.out.print("Ingrese el peso (kg): ");
            peso = sc.nextDouble();

            if (peso <= 0) {
                System.out.println("Peso inválido. Debe ser un valor positivo mayor que 0 kg.");
            } else if (peso > 500) {
                System.out.println("Peso inusual. Ingrese un valor realista (menor a 500 kg).");
            }
        } while (peso <= 0 || peso > 500);
        this.setPeso_kg(peso);

         /* Cálculo de IMC y Frecuencia Cardiaca */
        Integer edad = this.calculoEdad(
                fecha_actual.year,
                fecha_actual.month,
                fecha_actual.day
        );

        this.heartRate(edad);
        Double imc = this.Bmi();
        System.out.println("Su IMC es: " + imc);
        this.imcTabla(imc);
    }

    public Integer calculoEdad(Integer year, Integer mes, Integer dia) {
        int edad;

        if (mes > mes_nacimiento ) {
            edad = year - year_nacimiento;
            System.out.println("La edad es: " + edad);

        } else if(mes.equals(mes_nacimiento) && (dia > dia_nacimiento)){
            edad = year - year_nacimiento;
            System.out.println("La edad es: " + edad);
        }else {
            edad = (year - year_nacimiento) - 1;
            System.out.println("La edad es: " + edad);
        }

        return edad;
    }


    //frecuencia cardiaca
    public void heartRate (Integer edad){

        int hrMax =(220-edad);
        double Li=hrMax*0.5;
        double Ls=hrMax*0.85;
        System.out.println("La frecuencia máxima de " + this.nombre + " es "+hrMax+".");
        System.out.println("Se espera que su frecuencia esté entre "+Li+"lpm y "+Ls+"lmp");

    }


    public Double Bmi (){
        double altura_m = altura_cm / 100;
        return peso_kg/(altura_m*altura_m);
    }


    public void imcTabla(double imc){

        System.out.println("===========================================");
        System.out.println("     TABLA DE ÍNDICE DE MASA CORPORAL (IMC)");
        System.out.println("===========================================");
        System.out.println("|  Clasificación  |       Rango (IMC)      |");
        System.out.println("-------------------------------------------");
        System.out.println("|  Bajo peso      |   Menos de 18.5        |");
        System.out.println("|  Normal         |   18.5 - 24.9          |");
        System.out.println("|  Sobrepeso      |   25.0 - 29.9          |");
        System.out.println("|  Obeso          |   30.0 o más           |");
        System.out.println("===========================================");


        if (imc < 18.5){
            System.out.println("Estas BAJO PESO");
        }else if (imc >=  18.5 && imc <= 24.9){
            System.out.println("Tienes un PESO NORMAL");
        }else if (imc >= 25){
            System.out.println("Tienes SOBRE PESO");
        }else{
            System.out.println("Estas OBESO");
        }
    }

}
