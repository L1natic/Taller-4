import javax.swing.*;//Cree una clase llamada Fecha, que incluya tres variables de instancia:
// Un mes (tipo int), un día (tipo int) y un año (tipo int).
//Su clase debe tener un constructor que inicialice las tres variables de instancia
// y debe asumir que los valores que se proporcionan son correctos.
//Proporcione un metodo establecer y un metodo obtener para cada variable de instancia.
//Proporcione un metodo mostrarFecha
// Que muestre el mes, día y año, separados por barras diagonales (/).
//Escriba una aplicación de prueba llamada PruebaFecha
void main() {
    Fecha dia1= new Fecha(3,7,2025);
    int Validar=2;
    dia1.Mostrar_Fecha();

    while(Validar!=0){
        Validar = Integer.parseInt(JOptionPane.showInputDialog("¿Desea cambiar la fecha actual?(1=si  0=no):"));
        if(Validar==1){
            dia1.mes_validacion();
            dia1.dia_validacion();
            /**dia1.year_validacion();*/
            Validar=0;
            dia1.Mostrar_Fecha();
        } else if (Validar>1 || Validar<0) {
            JOptionPane.showMessageDialog(null,"Valor no válido, intente otra vez");
        }
    }
}
